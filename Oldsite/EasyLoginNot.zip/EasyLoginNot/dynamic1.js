﻿//Dynamic assessmentitem bank for dynamic-assess-2-radio.html
var bank1=[];
bank1[0]='int x=19, y=-1;<br>for(int i=1,y++;i<=10;i++)&nbsp;--x;<br>System.out.print(y+","+x);<br>印出結果?';
bank1[1]='int x=8, y=2, i=6;<br>for(i=1,--y;i>=6;--i) --x;<br>System.out.print(i+","+x);<br>印出結果?';
var select1=[];
select1[0]="9,8";
select1[1]="0,9";
select1[2]="9,9";
select1[3]="9,8";
select1[4]="0,2";
select1[5]="2,2";
select1[6]="1,8";
select1[7]="6,8";
var cans=[2,3];

var prompt1=[];
prompt1[0]="注意for第一段執行次數";
prompt1[1]="for第二段之條件";
prompt1[2]="注意for執行順序";
prompt1[3]="for第一段只執行1次，for&nbsp;body執行10次";
prompt1[4]="注意for第一段執行次數";
prompt1[5]="for第二段之條件";
prompt1[6]="注意for執行順序，是否為空?圈";
prompt1[7]="for第一段只執行1次，for body執行0次";

//int x=19, y=-1;
//for(int i=1,y++;i<=10;i++) --x;
//System.out.print(y+","+x);
//印出結果?
//注意for第一段執行次數
//for第二段之條件
//注意for執行順序
//for第一段只執行1次，for body執行10次

//int x=8, y=2, i=6;
//for(i=1,--y;i>=6;--i) --x;
//System.out.print(i+","+x);
//印出結果?
//0,2
//2,2
//1,8
//6,8
//注意for第一段執行次數
//for第二段之條件
//注意for執行順序，是否為空?圈
//for第一段只執行1次，for body執行0次